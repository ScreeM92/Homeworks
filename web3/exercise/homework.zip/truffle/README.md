# truffle-init-default

Default project for Truffle: example contracts, migrations and tests

## Usage

See the [Truffle documentation](http://truffleframework.com/docs/) for more info.
